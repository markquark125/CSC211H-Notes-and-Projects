// Roomba class header file.

#ifndef ROOMBA_H
#define ROOMBA_H

class Roomba {
    private:
        int xPosition;       // To hold x coordinate of Roomba
        int yPosition;       // To hold y coordinate of Roomba

        // Const ints for limits of room (room dimenstions)
        const int XMAX = 10;
        const int YMAX = 10;
        const int XMIN = 0;
        const int YMIN = 0;
        
    public:
        Roomba();           // Default constructor
        void display();     // Display Roomba's curr position.

        // Move in compass position by one.
        void moveLeft(); 
        void moveRight();
        void moveDown();
        void moveUp();

        // Move in compass direction until obstacle.
        void moveNorth();
        void moveSouth();
        void moveEast();
        void moveWest();
};

#endif