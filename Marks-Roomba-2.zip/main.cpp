/*
Roomba class assignment (version 2)
main.ccp file
*/

#include <iostream>
#include "Roomba.h"
using namespace std;

int main() 
{
    char command;      // char variable for user input
    Roomba Roomba1;    // Roomba object.

    cout << "ATTENTION!\tATTENTION!\tATTENTION!\n"
         << "Roomba Commander! Tell roomba where to go.\n"
         << "Enter n, s, w, or e to move by one space towards compass direction.\n"
         << "Enter N, S, W, or E to move nonstop towards compass direction.\n";
    Roomba1.display();
    cout << "To quit, enter Q.\nEnter command: ";
    cin >> command;

    // Created if/if else/else branches for valid and invalid inputs.
    while (command != 'Q' && command != 'q')
    {
        if (command == 'n')
        {
            Roomba1.moveUp();
            Roomba1.display();
            cout << "Enter command: ";
            cin >> command;
        }
        else if (command == 's')
        {
            Roomba1.moveDown();
            Roomba1.display();
            cout << "Enter command: ";
            cin >> command;
        }
        else if (command == 'e')
        {
            Roomba1.moveRight();
            Roomba1.display();
            cout << "Enter command: ";
            cin >> command;
        }
        else if (command == 'w')
        {
            Roomba1.moveLeft();
            Roomba1.display();
            cout << "Enter command: ";
            cin >> command;
        }
        else if (command == 'N')
        {
            Roomba1.moveNorth();
            Roomba1.display();
            cout << "Enter command: ";
            cin >> command;
        }
        else if (command == 'S')
        {
            Roomba1.moveSouth();
            Roomba1.display();
            cout << "Enter command: ";
            cin >> command;
        }
        else if (command == 'E')
        {
            Roomba1.moveEast();
            Roomba1.display();
            cout << "Enter command: ";
            cin >> command;
        }
        else if (command == 'W')
        {
            Roomba1.moveWest();
            Roomba1.display();
            cout << "Enter command: ";
            cin >> command;
        }
        else
        {
            cout << "Invalid entry. Enter command: ";
            cin >> command;
        }
    }

    cout << "PROGRAM TERMINATED.\n";
}