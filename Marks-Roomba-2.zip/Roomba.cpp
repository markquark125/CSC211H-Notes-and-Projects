// Roomba class implementation file. Roomba.cpp file

#include "Roomba.h"
#include <iostream>
using namespace std;

// Default constructor. Default coordinates (1, 1).
Roomba::Roomba() {
    xPosition = 1;
    yPosition = 1;
}

// Display Roomba's xy coordinates
void Roomba::display() {
    cout << "Roomba is at position (" << xPosition
         << ", " << yPosition << ")\n";
}

// Move Roomba up by 1
void Roomba::moveUp() {
    cout << "Roomba moving up...\n";
    if (yPosition < YMAX)
        yPosition++;
    else
        cout << "OBSTACLE DETECTED (NORTH WALL).\n";
}

// Move Roomba down by 1
void Roomba::moveDown() {
    cout << "Roomba moving down...\n";
    if (yPosition > YMIN)
        yPosition--;
    else
        cout << "OBSTACLE DETECTED (SOUTH WALL).\n";
}

// Move Roomba left by 1
void Roomba::moveLeft() {
    cout << "Roomba is moving left...\n";
    if (xPosition > XMIN)
        xPosition--;
    else
        cout << "OBSTACLE DETECTED (WEST WALL)\n";
}

// Move Roomba right by 1
void Roomba::moveRight() {
    cout << "Roomba moving right...\n";
    if (xPosition < XMAX)
        xPosition++;
    else
        cout << "OBSTACLE DETECTED (EAST WALL)\n";
}

// Move Roomba North nonstop
void Roomba::moveNorth() {
    cout << "Roomba moving North...\n";
    for (int i = yPosition; i < YMAX; i++)
        yPosition++;
    cout << "OBSTACLE DETECTED (NORTH WALL)\n";
}

// Move Roomba South nonstop
void Roomba::moveSouth() {
    cout << "Roomba moving South...\n";
    for (int i = yPosition; i > YMIN; i--)
        yPosition--;
    cout << "OBSTACLE DETECTED (SOUTH WALL)\n";
}

// Move Roomba West nonstop
void Roomba::moveWest() {
    cout << "Roomba moving West...\n";
    for (int i = xPosition; i > XMIN; i--)
        xPosition--;
    cout << "OBSTACLE DETECTED (WEST WALL)\n";
}

// Move Roomba East nonstop
void Roomba::moveEast() {
    cout << "Roomba moving East...\n";
    for (int i = xPosition; i < XMAX; i++)
        xPosition++;
    cout << "OBSTACLE DETECTED (EAST WALL)\n";
}