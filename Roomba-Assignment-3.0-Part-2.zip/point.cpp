#include "point.h"

// Set coordinates
void Point::set(int x, int y)
{
    this->x = x;
    this->y = y;
}

// Print coordinates
void Point::print() const
{
    cout << "(" << getX() << ", " << getY() << ")";
}

// Following functions are to get functions
int Point::getX() const
{
    return x;
}

int Point::getY() const
{
    return y;
}
