   #include "robot.h"
#include "world.h"
#include "point.h"
#include <math.h>
using namespace std;

// Works like a constructor except is not automatically initialized
void Robot::init()
{
    robotLocation.set(0,0);
    robotOrientation = east;

}

Robot::Robot()
{}

Robot::Robot(const Robot &obj)
{   
    int x, y;
    x = obj.robotLocation.getX();
    y = obj.robotLocation.getY();

    robotLocation.set(x, y);

    robotOrientation = obj.robotOrientation;
}


// Print robot location and orientation
void Robot::print() const
{
    cout << "I am at ";
    robotLocation.print();
    cout << " and I am facing ";

    switch(robotOrientation)
    {
        case north:
            cout << "North.\n";
            break;
        case south:
            cout << "South.\n";
            break;
        case east:
            cout << "East.\n";
            break;
        case west:
            cout << "West.\n";
            break;
    }
}

// Set robot orientation
void Robot::setOrientation(orientation_type orientation)
{
    switch(orientation)
    {
        case north:
            robotOrientation = north;
            break;
        case south:
            robotOrientation = south;
            break;
        case east:
            robotOrientation = east;
            break;
        case west:
            robotOrientation = west;
            break;
    }    
}

// bool function to evaluate if robot can move forward
bool Robot::forward()
{
    // Store current x,y of Roomba to be used in comparison
    int x = robotLocation.getX();
    int y = robotLocation.getY();

    // Checks robot orientation and if robot within boundary, assigns robot
    // with relative coordinates and returns true. Else, return false.
    switch(robotOrientation)
    {
        case north:
            if (robotLocation.getY() < 9)
            {
                robotLocation.set(x, y+1);
                return true;
            }
        case south:
            if (robotLocation.getY() > 0)
            {
                robotLocation.set(x, y-1);
                return true;
            }
        case east:
            if (robotLocation.getX() < 9)
            {
                robotLocation.set(x+1, y);
                return true;
            }
        case west:
            if (robotLocation.getX() > 0)
            {
                robotLocation.set(x-1, y);
                return true;
            }
        default: 
            return false;
    }
}

// Turn robot clockwise
void Robot::turnCW()
{
    switch(robotOrientation)
    {
        case north:
            robotOrientation = east;
            break;
        case south:
            robotOrientation = west;
            break;
        case east:
            robotOrientation = south;
            break;
        case west:
            robotOrientation = north;
            break;
    }
}

// Turn robot anticlockwise
void Robot::turnAntiCW()
{
    switch(robotOrientation)
    {
        case north:
            robotOrientation = west;
            break;
        case south:
            robotOrientation = east;
            break;
        case east:
            robotOrientation = north;
            break;
        case west:
            robotOrientation = south;
            break;
    }
}

// Following functions are to test if robot is at boundary (N,E,W,S)
bool Robot::eastEnd()
{
    if (robotLocation.getX() == 9)
        return true;
    else
        return false;
}

bool Robot::westEnd()
{
    if (robotLocation.getX() == 0)
        return true;
    else
        return false;
}

bool Robot::northEnd()
{
    if (robotLocation.getY() == 9)
        return true;
    else
        return false;
}

bool Robot::southEnd()
{
    if (robotLocation.getY() == 0)
        return true;
    else
        return false;
}

// IF robot at East end, turn CW -> move up/forward/ turn CW
bool Robot::zag()
{
    if (eastEnd())
    {
        turnCW();
        forward();
        turnCW();
        return true;
    }
    else
        return false;
}

// IF robot at West end, turn antiCW -> move up/forward/ turn antiCW
bool Robot::zig()
{
    if (westEnd())
    {
        turnAntiCW();
        forward();
        turnAntiCW();
        return true;
    }
    else
        return false;
}

Robot Robot::operator++(int)
{
    forward();
    return *this;
}

Robot Robot::operator--(int)
{
    turnCW();
    turnCW();      // Turn 180
    forward();     // Move forward
    turnCW();      
    turnCW();      // Turn 180. Back at intial orientation.
    return *this;
}

double Robot::operator-(Robot &otherRobo)
{
    double temp = 0;

    // Add square of difference-in-X-position.
    temp += pow((this->robotLocation.getX() - otherRobo.robotLocation.getX()), 2);
    // Add square of difference-in-Y-position.
    temp += pow((this->robotLocation.getY() - otherRobo.robotLocation.getY()), 2);

    return sqrt(temp);
}

bool Robot::operator==(Robot &otherRobo)
{
    bool equal = false;
    
    if (this->robotLocation.getX() == otherRobo.robotLocation.getX())
    {
        if (this->robotLocation.getY() == otherRobo.robotLocation.getY())
        {
            equal = true;
        }
    }
    return equal;
}
