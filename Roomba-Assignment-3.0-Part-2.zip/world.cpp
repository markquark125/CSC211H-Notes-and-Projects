#include "world.h"
#include <iostream>
using namespace std;

// Iterate throught array of Point objects and print coordinate
void World::print() const
{
    for (int i = 0; i < 3; i++)
    {
        cout << "Coin " << (i+1) << " at ("
             << arrayOfCoins[i].getX() << ", "
             << arrayOfCoins[i].getY() << ")"
             << endl;
    }
}

// Set coordinates for each ith coin
void World::set(int i, int x, int y)
{
    arrayOfCoins[i].set(x,y);
}
