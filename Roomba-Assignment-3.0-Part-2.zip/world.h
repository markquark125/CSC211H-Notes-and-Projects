
#include "point.h"
using namespace std;

#ifndef WORLD_H
#define WORLD_H

class World
{
    public:
        Point arrayOfCoins[3];
    public:
        void print() const;
        void set(int i, int x, int y);       
};

#endif