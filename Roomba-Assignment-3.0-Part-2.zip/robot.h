

#include "point.h"
#include "world.h"
#include <iostream>
using namespace std;

#ifndef ROBOT_H
#define ROBOT_H

class Robot
{
    private:
        Point robotLocation;
        enum orientation_type{north,south,west,east};
        orientation_type robotOrientation;

    public:
        Robot();
        // Copy constructor
        Robot(const Robot &obj);

        void init();
        void print() const;
        void setOrientation(orientation_type Orient);
        bool forward();
        void turnCW();
        void turnAntiCW();
        bool eastEnd();
        bool westEnd();
        bool northEnd();
        bool southEnd();
        bool zag();
        bool zig();

        // Overloaded operators
        Robot operator++(int);
        Robot operator--(int);
        double operator-(Robot & );
        bool operator==(Robot & );
        
};
#endif