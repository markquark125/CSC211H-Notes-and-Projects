
// Roomba Assignment 3.0 (Part 2)
// Overloaded functions defined in robot.cpp
#include <iostream>
#include <iomanip>
#include "point.h"
#include "robot.h"
#include "world.h"
using namespace std;


int main() 
{
    Robot Roomba1;

    // Set roomba at (0, 0)
    Roomba1.init();

    // Try the ++ overloaded operator.
    Roomba1.print();
    Roomba1++;        // Move Roomba once.
    Roomba1.print();
    Roomba1++;        // Move Roomba once.
    Roomba1.print();

    // Try the -- overloaded operator.
    Roomba1--;
    Roomba1.print();
    Roomba1--;
    Roomba1.print();
    Roomba1--;         // Already at (0, 0). Test if can move to (-1, 0)
    Roomba1.print();   // Nope. We good.

    // Move Roomba1 to (2, 1) to test copy constructor
    Roomba1++;
    Roomba1++;
    Roomba1.turnAntiCW();
    Roomba1++;
    cout << "\nRoomba1: ";
    Roomba1.print();

    // Test the copy constructor.
    Robot Roomba2 = Roomba1;
    cout << "Roomba2: ";
    Roomba2.print();

    // Created a new Robot called test.
    cout << "\nTest Robot: ";
    Robot *test = new Robot;
    test->init();
    test->print();

    // Test the - overloaded operator.
    // Sqrt(5) approximately 2.24
    cout << fixed << showpoint << setprecision(2);
    cout << "\nDistance between test Robot and Roomba1: " << *test - Roomba1;

    // Will return nonzero if true.
    cout << "\n\nTest overloaded == operator: "
         << (Roomba1 == Roomba2) << endl;

    return 0;
}
/****************************** END OF MAIN **************************/ 

